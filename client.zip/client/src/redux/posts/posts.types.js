export const GET_POSTS = 'GET_POSTS';
export const GET_POST = 'GET_POST';
export const GET_TOP_POSTS = 'GET_TOP_POSTS';
export const GET_TAG_POSTS = 'GET_TAG_POSTS';
export const POST_ERROR = 'POST_ERROR';
export const DELETE_POST = 'DELETE_POST';
export const ADD_POST = 'ADD_POST';