export const GET_TAGS = 'GET_TAGS';
export const TAG_ERROR = 'TAG_ERROR';