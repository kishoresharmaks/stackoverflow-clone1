export const GET_ANSWERS = 'GET_ANSWERS';
export const ANSWER_ERROR = 'ANSWER_ERROR';
export const DELETE_ANSWER = 'DELETE_ANSWER';
export const ADD_ANSWER = 'ADD_ANSWER';